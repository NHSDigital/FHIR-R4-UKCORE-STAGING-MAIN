---
topic: Home-Downloads-15ba699d-87f6-4e83-9e54-5b763c0744e2
---
## Downloads

<table id="assets">
<tr>
<th>Description</th>
<th>Status</th>
<th>Link</th>
</tr>
<tr>
<td>Release package for UK Core 1.0.1 - STU1</td>
<td>Active</td>
<td><a href="https://simplifier.net/packages/fhir.r4.ukcore.stu1/1.0.1">ukcore.stu1 1.0.1</a></td>
</tr>

</table>

---

