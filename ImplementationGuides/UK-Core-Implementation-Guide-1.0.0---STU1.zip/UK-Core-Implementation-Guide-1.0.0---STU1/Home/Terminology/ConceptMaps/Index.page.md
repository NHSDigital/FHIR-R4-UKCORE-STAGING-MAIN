---
topic: Library-ConceptMaps-403c0b99-33cf-4694-939e-e4d1d1c65c33
---
## ConceptMaps

The UK Core does not define any ConceptMaps because none have currently been identified as usable across the whole of the UK. Where there is a need for a ConceptMap these should be done as part of a derived Implementation Guide. For example, NHS Digital could define ConceptMaps for Spine APIs to UK Core terminology resources.

---


















