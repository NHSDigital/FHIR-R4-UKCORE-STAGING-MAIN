## Sending a translation set 

In the case where a code was entered into the clinical system using a legacy coding system and the code was mapped to a SNOMED CT translation, the following scenario **SHALL** be considered. 

In SNOMED CT, all concept ids always have more than one associated description: all have at least one fully specified name and at least one additional associated synonym. Of these, exactly one fully specified name and one synonym will be declared to be “preferred” at any point in time within a Realm Language Reference Set, but which terms are designated “preferred” can and does change over time.

Therefore, in most cases where such mappings have been created, they will have been mapped to an explicit pairing of one SNOMED CT concept id and one of its legitimate description IDs. The particular description ID selected might also correspond to the preferred term but often does not.

Exceptionally, mappings could correspond to a SNOMED CT concept id only and so no particular description is declared in the map. In these cases the description originally entered by the clinician in the legacy coding system **SHALL** be considered to be the clinically relevant text.

<div class="tab">
 <button class="tablinks active" onclick="openTab(event, 'Table View')">Table View</button>
 <button class="tablinks" onclick="openTab(event, 'Tree View')">Tree View</button>
 <button class="tablinks" onclick="openTab(event, 'XML View')">XML View</button>
 <button class="tablinks" onclick="openTab(event, 'JSON View')">JSON View</button>
</div>

<div id="Table View" class="tabcontent" style="display:block">
  <h3>Table View</h3>
{{table:UKCore-Observation-Sn-Extension-CodingSCT-Potassium-Example}}
</div>

<div id="Tree View" class="tabcontent">
  <h3>Tree View</h3>
{{tree:UKCore-Observation-Sn-Extension-CodingSCT-Potassium-Example}}
</div>

<div id="XML View" class="tabcontent">
  <h3>XML View</h3>
{{xml:UKCore-Observation-Sn-Extension-CodingSCT-Potassium-Example}}
</div>

<div id="JSON View" class="tabcontent">
  <h3>JSON View</h3>
{{json:UKCore-Observation-Sn-Extension-CodingSCT-Potassium-Example}}
</div>

<br><br>

<div class="tab">
 <button class="tablinks active" onclick="openTab(event, 'Table View')">Table View</button>
 <button class="tablinks" onclick="openTab(event, 'Tree View')">Tree View</button>
 <button class="tablinks" onclick="openTab(event, 'XML View')">XML View</button>
 <button class="tablinks" onclick="openTab(event, 'JSON View')">JSON View</button>
</div>

<div id="Table View" class="tabcontent" style="display:block">
  <h3>Table View</h3>
{{table:UKCore-Condition-Sn-Extension-CodingSCT-MoleOfSkin-Example}}
</div>

<div id="Tree View" class="tabcontent">
  <h3>Tree View</h3>
{{tree:UKCore-Condition-Sn-Extension-CodingSCT-MoleOfSkin-Example}}
</div>

<div id="XML View" class="tabcontent">
  <h3>XML View</h3>
{{xml:UKCore-Condition-Sn-Extension-CodingSCT-MoleOfSkin-Example}}
</div>

<div id="JSON View" class="tabcontent">
  <h3>JSON View</h3>
{{json:UKCore-Condition-Sn-Extension-CodingSCT-MoleOfSkin-Example}}
</div>

---
