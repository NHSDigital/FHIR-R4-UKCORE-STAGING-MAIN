---
topic: Home-Glossary-c85310e1-4ddf-4096-8669-70cf1093343f
---
{{render:hl7fhirukcorer4/index-duplicate-49}}