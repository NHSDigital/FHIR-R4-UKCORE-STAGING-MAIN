## `birthDate`

The patient's date of birth. An approximate date may be used (e.g. just the year) where the full date is not known.

birthDate includes an extension <a href="https://hl7.org/fhir/R4/extension-patient-birthTime.html" target="_blank">Common Extension patient-birthTime</a> This SHOULD be included when the birth time is relevant.

---
