## {{page-title}}


More information about the extensions can be found using the link below.


<a href="https://hl7.org/fhir/R4/extension-patient-birthPlace.html">Common Extension patient-birthPlace</a>

---
