## {{page-title}}

More information about this extension can be found using the link below:

<a href="https://hl7.org/fhir/R4/extension-patient-interpreterRequired.html">Common Extension patient-interpreterRequired</a>.

---
