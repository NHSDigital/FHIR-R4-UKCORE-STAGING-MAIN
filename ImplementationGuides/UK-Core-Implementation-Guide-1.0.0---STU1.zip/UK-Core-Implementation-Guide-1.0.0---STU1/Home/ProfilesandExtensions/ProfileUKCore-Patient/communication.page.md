## `communication`

One or more instances of this element can be used to list the languages the patient is able to communicate in. 

Use the value set below. One of these instances SHOULD be marked as preferred. 

{{pagelink:ValueSet-UKCore-HumanLanguage}}.

---

