## `telecom`


A contact detail (e.g. a telephone number or an email address) by which the patient may be contacted. 

telecom uses the {{pagelink:ContactPoint}} data type.

---



 