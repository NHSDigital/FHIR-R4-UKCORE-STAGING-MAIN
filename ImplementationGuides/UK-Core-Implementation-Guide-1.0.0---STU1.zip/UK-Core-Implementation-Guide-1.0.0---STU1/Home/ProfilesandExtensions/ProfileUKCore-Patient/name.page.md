## `name`


The patient name represented by the {{pagelink:HumanName}} data type.

Multiple names can be included.

---
