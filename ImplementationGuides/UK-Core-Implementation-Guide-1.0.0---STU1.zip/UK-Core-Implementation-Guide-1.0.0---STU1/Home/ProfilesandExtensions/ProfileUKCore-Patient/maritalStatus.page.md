## `maritalStatus`

Use a value from {{pagelink:ValueSet-UKCore-PersonMaritalStatusCode}}.

---
