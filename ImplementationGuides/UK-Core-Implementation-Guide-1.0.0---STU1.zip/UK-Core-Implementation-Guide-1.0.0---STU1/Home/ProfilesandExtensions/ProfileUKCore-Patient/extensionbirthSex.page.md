## {{page-title}}


More information about this extension can be found using the link below:

{{pagelink:ExtensionUKCore-BirthSex}}.

---