## `managingOrganization`

An Organization that is the custodian of the patient record (such as a general practice).

The `managingOrganization` may change according to the setting (a mental health record may be managed by a MH trust), whereas the `generalPractitioner` points to your GP or GP Practice.

---
