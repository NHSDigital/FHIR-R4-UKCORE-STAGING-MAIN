## {{page-title}}

{{pagelink:ExtensionUKCore-AllergyIntoleranceEnd}} for the date when the allergy or intolerance `clinicalStatus` is updated to `inactive` or `resolved`.

---
