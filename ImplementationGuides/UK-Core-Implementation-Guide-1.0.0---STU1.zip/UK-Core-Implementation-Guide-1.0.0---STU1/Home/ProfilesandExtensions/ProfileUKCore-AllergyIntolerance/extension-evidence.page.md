## {{page-title}}

{{pagelink:ExtensionUKCore-Evidence}} to reference a `DiagnosticReport` resource for investigations that confirm the certainty of the allergy or intolerance diagnosis.

---