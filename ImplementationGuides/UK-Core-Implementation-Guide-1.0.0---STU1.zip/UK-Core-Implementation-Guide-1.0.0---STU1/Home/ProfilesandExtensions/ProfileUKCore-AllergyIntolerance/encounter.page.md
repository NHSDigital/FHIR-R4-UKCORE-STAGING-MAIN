## `encounter`

A reference to the encounter resource which SHOULD conform to <a href="https://simplifier.net/hl7fhirukcorer4/ukcoreencounter">Profile UKCore-Encounter</a>.

---
