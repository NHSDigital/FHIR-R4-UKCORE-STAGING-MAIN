## `lastOccurrence`

Represents the date and/or time of the last known occurrence of a reaction event.

---
