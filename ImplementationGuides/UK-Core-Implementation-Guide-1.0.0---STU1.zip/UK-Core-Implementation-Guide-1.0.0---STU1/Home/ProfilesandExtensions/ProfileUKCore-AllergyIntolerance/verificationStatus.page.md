## `verificationStatus`


An optional value from a required terminology binding containing the values;
- `unconfirmed`
- `confirmed`
- `refuted`
- `entered-in-error`.

Note: The use of `entered-in-error` dictates the population of the `clinicalStatus` element.

---
