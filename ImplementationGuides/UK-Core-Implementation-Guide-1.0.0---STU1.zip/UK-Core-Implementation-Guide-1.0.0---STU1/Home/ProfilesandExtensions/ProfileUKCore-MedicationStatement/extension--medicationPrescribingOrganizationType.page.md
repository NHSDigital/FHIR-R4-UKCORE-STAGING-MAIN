## {{page-title}}

An extension to identify if the medication was `prescribed-at-gp-practice` or `prescribed-by-another-organisation`.

This extension is likely only to be populated by GP systems.

More information on this extension can be found using the link below.

{{pagelink:Extension-UKCore-MedicationPrescribingOrganizationType}}.

---