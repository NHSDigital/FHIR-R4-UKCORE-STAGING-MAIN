## `derivedFrom`

This should be used only to reference information that can not be referenced by `MedicationStatement.basedOn`. 

<div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-information"></i><h4>Important:</h4>
Population of both <code>derivedFrom</code> and <code>basedOn</code> SHOULD be avoided as potentially confusing. 
</div>

---
