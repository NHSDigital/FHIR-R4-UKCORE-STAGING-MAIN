## `statusReason`

Used to expand on the intent for the status of the `MedicationStatement`.

An example use-case for this could be if an organisation sets a medication status to `on-hold` with the intent to restart the medication at some point (move back to `active`).

---
