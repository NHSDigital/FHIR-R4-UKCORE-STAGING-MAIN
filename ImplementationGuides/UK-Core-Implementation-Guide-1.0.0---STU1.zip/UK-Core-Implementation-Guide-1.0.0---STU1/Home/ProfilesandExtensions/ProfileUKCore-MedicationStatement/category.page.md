## `category`

The {{pagelink:ValueSet-UKCore-MedicationStatementCategory}} has been extended with `leave` and `discharge` to align with the equivalent value set used by `MedicationRequest`. 

---
