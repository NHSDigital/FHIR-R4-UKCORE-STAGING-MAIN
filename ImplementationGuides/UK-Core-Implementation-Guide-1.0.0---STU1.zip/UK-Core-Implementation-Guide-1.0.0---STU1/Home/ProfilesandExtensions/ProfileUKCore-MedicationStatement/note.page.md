## `note`

If present, notes must be displayed by consuming systems. 

Where author is known and to be shared, the use of `authorReference` is preferred over using a free-text version `authorString`.


---
