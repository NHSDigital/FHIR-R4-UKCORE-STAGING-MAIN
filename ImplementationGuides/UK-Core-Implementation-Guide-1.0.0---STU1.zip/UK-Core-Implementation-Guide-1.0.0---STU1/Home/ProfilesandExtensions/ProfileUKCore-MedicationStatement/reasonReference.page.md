## `reasonReference`

Further details of why the medication is being taken by reference to UK Core `Condition` or `Observation`.

---
