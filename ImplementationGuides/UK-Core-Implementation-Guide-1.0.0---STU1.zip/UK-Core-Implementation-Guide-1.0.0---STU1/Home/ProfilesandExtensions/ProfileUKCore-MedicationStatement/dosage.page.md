## `dosage`

Consider aligning to the Implementation Guide for Digital Medicines, but as a minimum, `dosage.text`.

---
