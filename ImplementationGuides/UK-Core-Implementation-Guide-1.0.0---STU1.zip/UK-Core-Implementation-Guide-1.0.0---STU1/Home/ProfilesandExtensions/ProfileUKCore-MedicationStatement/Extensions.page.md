## Extensions

More information about the extensions can be found using the links below.

<table id="assets">
<tr>
<th width="20%">Extension</th>
<th width="20%">Context</th>
<th width="30%">Link</th>
<th width="30%">Comment</th>
</tr>
<tr>
<td>medicationPrescribingOrganizationType</td>
<td>MedicationStatement</td>
<td>{{pagelink:Extension-UKCore-MedicationPrescribingOrganizationType}}</td>
<td>An extension to identify if the medication was <code>prescribed-at-gp-practice</code> or <code>prescribed-by-another-organisation</code>.

This extension is likely only to be populated by GP systems.</td>
</tr>
<tr>
<td>medicationStatementLastIssueDate</td>
<td>MedicationStatement</td>
<td>{{pagelink:Extension-UKCore-MedicationStatementLastIssueDate}}</td>
<td>An extension for the date or date/time that the medication described in the <code>MedicationStatement</code> was last requested/prescribed.

The presence of this data does not imply medication has been dispensed or supplied to the patient.</td>
</tr>
<tr>
<td>pharmacistVerifiedIndicator</td>
<td>MedicationStatement</td>
<td>{{pagelink:ExtensionUKCore-PharmacistVerifiedIndicator}}</td>
<td></td>
</tr>
</table>

---


