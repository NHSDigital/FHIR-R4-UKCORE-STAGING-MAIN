## `partOf`

This SHOULD NOT be used as the use-case and purpose is ambiguous.

---
