## `identifier`

It is recommended that the `identifier` value is an ODS (*Organisation Data Service*) site code. This has been profiled using the slice `Location.identifier:odsSiteCode`.

For more information on ODS, refer to the Glossary

---

