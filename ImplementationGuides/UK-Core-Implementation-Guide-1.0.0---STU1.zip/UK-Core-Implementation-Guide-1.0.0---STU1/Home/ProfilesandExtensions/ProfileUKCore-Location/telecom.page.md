## `telecom`

A contact detail (e.g. a telephone number or an email address) by which the location may be contacted. 

`telecom` uses the {{pagelink:ContactPoint}} datatype.

---