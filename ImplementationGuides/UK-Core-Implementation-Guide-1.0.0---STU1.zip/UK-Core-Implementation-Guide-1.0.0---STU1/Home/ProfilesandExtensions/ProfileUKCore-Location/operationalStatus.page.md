## `operationalStatus`

The current operational status of the location (typically only for a bed/room).

This refers to the current operational status of a location not its general availability which is represented by `Location.status`.

The operational status covers values most relevant to beds (but can also apply to rooms/units/chairs/etc. such as an isolation unit/dialysis chair). This typically covers concepts such as contamination, housekeeping, and other activities like maintenance.

The [CodeSystem: bedStatus](http://terminology.hl7.org/CodeSystem/v2-0116) has a preferred binding in the FHIR standard and no UK Core alternative is currently used. Implementers MAY choose to use an alternative CodeSystem if required by their use case.

---

