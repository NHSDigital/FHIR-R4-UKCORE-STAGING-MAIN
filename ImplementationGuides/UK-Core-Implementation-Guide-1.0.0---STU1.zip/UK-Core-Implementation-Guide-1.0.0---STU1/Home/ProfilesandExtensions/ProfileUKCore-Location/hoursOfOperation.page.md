## `hoursOfOperation`
What days/times during a week is this location usually open.

Opening times can be specified as the opening and closing times for each day of the week. Where a location is open 24 hours opening and closing times SHOULD NOT be specified and `Location.hoursOfOperation.allDay` SHOULD be set to `true`.

---