## `managingOrganization`
The organisation responsible for the provisioning and upkeep of the location as a reference. The resource being referenced SHOULD conform to {{pagelink:Profile-Organization-3826477b-c49f-45cd-a6a4-a179826dd3a8}}.

---