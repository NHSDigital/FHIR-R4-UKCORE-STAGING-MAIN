## `partOf`

Another Location of which this Location is physically a part of, as a reference. The resource being referenced SHOULD conform to {{pagelink:Profile-Location-9738cf88-9ba3-4fc6-8efb-58b9583498f2}}.

---

