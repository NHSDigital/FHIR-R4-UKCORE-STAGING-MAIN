## `name`

The name of the practitioner using the {{pagelink:HumanName}} datatype.

---