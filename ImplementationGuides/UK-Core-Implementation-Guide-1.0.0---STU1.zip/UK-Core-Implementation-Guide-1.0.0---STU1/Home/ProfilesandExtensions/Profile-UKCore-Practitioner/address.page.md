## `address`

The address of the Practitioner using the {{pagelink:Address}} datatype.

---