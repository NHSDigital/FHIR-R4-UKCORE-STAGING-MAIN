## `communication`
A language that the practitioner can use to communicate with patients about their health.

Use a value from {{pagelink:ValueSet-UKCore-HumanLanguage}}.

---

