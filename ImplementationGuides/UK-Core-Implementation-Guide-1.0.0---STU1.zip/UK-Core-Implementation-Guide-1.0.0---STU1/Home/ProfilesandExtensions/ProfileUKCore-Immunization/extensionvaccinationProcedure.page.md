## {{page-title}}

{{pagelink:ExtensionUKCore-VaccinationProcedure}} to hold an immunisation procedure code.

This extension SHOULD be used when status=`completed`. 

This relates to the vaccine that was administered (procedure) and SHOULD be a SNOMED CT from {{pagelink:ValueSet-UKCore-VaccinationProcedure}}

---


