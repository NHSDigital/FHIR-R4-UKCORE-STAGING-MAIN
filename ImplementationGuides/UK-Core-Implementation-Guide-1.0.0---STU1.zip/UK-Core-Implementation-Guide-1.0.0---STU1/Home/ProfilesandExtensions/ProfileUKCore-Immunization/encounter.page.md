## `encounter`

The visit or admission or other contact between patient and healthcare provider that the immunisation was performed as part of. This is done by reference to the encounter which SHOULD conform to <a href="https://simplifier.net/hl7fhirukcorer4/ukcoreencounter">Profile UKCore-Encounter</a>.

---
