## `statusReason`

Indicates the reason the immunisation event was not performed using a code from the {{pagelink:ValueSet-UKCore-ReasonImmunizationNotAdministered}}.

---