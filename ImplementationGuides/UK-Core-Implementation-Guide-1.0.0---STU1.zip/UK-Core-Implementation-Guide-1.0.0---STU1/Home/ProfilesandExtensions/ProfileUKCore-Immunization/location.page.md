## `location`

The service delivery location where the vaccine administration occurred by reference to the location. The resource being referenced should conform to {{pagelink:Profile-Immunization-3af021ba-778f-4c94-ba11-eec8146df159}}.

---