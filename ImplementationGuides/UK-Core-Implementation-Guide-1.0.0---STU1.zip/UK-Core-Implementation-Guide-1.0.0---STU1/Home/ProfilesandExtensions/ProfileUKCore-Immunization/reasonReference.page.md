## `reasonReference`

Why immunisation occurred by reference to `Condition`, `Observation` or `DiagnosticReport`. The resource being referenced SHOULD conform to one of the following:

- <a href="https://simplifier.net/hl7fhirukcorer4/ukcorecondition">Profile UKCore-Condition</a>
- <a href="https://simplifier.net/hl7fhirukcorer4/ukcoreobservation">Profile UKCore-Observation</a>
- <a href="https://simplifier.net/hl7fhirukcorer4/ukcorediagnosticreport">Profile UKCore-DiagnosticReport</a> 

---