## {{page-title}}

{{pagelink:ExtensionUKCore-ParentPresent}} which indicates if a parent was present at an immunisation.

---