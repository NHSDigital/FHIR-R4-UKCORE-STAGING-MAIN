## {{page-title}}

More information about the extensions can be found using the link below.

<a href="https://www.hl7.org/fhir/R4/extension-organization-period.html">Common Extension organization-period</a>.

---