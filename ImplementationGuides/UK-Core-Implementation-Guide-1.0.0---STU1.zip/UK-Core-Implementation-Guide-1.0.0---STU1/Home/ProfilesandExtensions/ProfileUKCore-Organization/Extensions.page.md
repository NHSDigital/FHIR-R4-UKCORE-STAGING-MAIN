## Extensions

More information about the extensions can be found using the links below.

<table id="assets">
<tr>
<th width="30%">Extension</th>
<th width="30%">Context</th>
<th width="40%">Link</th>
</tr>
<tr>
<td>mainLocation</td>
<td>Organization</td>
<td>{{pagelink:ExtensionUKCore-MainLocation}}</td>
</tr>
<tr>
<td>organizationPeriod</td>
<td>Organization</td>
<td><a href="https://www.hl7.org/fhir/R4/extension-organization-period.html" target="_blank">Common Extension organization-period</a></td>
</tr>
</table>

---

