## `partOf`

Part of referenced event by reference. The resource being referenced SHOULD conform to the one of the following:

- {{pagelink:Profile-MedicationAdministration-007326ee-0cd3-4bd8-9e08-6f4defa056c8}}
- <a href="https://simplifier.net/hl7fhirukcorer4/ukcoreprocedure" target="_blank">Profile UKCore-Procedure</a>

---
