## `statusReason`

A coded reason for why an administration was not performed.

SHOULD only be populated when the `status` is either `stopped`, `not-done` or `on-hold`.

---