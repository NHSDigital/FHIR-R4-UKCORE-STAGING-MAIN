## `statusReason`

A coded reason for why a dispense was not performed.

SHOULD only be populated when the `status` is either `cancelled`, `stopped` or `declined`.

---