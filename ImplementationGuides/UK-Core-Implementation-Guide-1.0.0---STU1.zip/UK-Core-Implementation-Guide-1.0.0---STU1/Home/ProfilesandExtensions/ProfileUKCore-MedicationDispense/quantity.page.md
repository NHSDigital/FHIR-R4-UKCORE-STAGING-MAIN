## `quantity`

This element could be useful for discharge prescriptions (TTO) when representing "1 of something", for example:

- 1 pack
- 1 tablet
- 1 bottle.

It may be simpler to _always_ express as dose units. For example;

- 14 tablets
- 50 ml.

---
