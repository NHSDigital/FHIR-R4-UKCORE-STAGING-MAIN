## `whenPrepared`

A timestamp, as close as business processes allow for when the dispensed medication was prepared, i.e. labelled and checked.

---
