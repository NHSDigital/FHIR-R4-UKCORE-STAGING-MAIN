## `performer`

The `performer.actor` element SHOULD either reference a `practitioner` or `organization` resource.

---
