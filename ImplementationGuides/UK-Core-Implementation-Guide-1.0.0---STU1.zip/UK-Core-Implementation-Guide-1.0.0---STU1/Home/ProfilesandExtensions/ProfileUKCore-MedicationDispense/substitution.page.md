## `substitution`

If omitted or has a value of `false` then substitution has **not** occurred.

**Important:** Additional guidance for the use of this element is pending further clinical consultation. A suitable definition and example use-cases for a `substitution` need to be defined.

For example;

- Is a sugar-free variant classed as a `substitution`?

- Is a generic variant of a drug classed as a `substitution`?

- Can a `substitution` be an entirely different medication, or should it be a new request?

- Should a <code>substitution</code> only be used, for example, if supplied in a different strength than requested?

---
