## `recorder`

The identification of the `recorder` where this is a different person to the `requester` provides an additional point of contact for any queries related to the medication request and is done by a reference. The resource being referenced SHOULD conform to one of the following:
- {{pagelink:Profile-Practitioner-96448d2b-cd33-42cb-b1db-f48ae31db401}}
- {{pagelink:Profile-PractitionerRole-91e0c0ae-8b79-41de-b8e1-4eeb30ab2565}}

---
