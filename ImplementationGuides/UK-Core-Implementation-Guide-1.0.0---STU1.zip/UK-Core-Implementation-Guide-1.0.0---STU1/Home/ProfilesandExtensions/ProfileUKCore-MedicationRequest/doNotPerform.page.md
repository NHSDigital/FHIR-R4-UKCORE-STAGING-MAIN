## `doNotPerform`

At this time it is advised that providers to **not support** this element within an implementation. 

Consumers SHALL check the value of this element prior to processing and, if doNotPerform is true, either appropriately process doNotPerform MedicationRequests (e.g. notify the user) or reject the resource. 

---
