## `intent`

The value `order` SHOULD be used to denote this is a medication request order.

---
