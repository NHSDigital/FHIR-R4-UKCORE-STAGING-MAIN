## `authoredOn`


SHOULD be populated with the date and time that the medication request was authored.

---
