## `note`

Use when the prescriber wishes to provide supporting textual information to the dispenser.


<div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-information"></i><h4>Important</h4>
This element SHALL NOT be used for dosing instructions.
</div>



---
