## `statusReason`

A coded reason for the current state of the medication request.

SHOULD only be populated when the `status` is `on-hold`, `cancelled` or `stopped`.

---
