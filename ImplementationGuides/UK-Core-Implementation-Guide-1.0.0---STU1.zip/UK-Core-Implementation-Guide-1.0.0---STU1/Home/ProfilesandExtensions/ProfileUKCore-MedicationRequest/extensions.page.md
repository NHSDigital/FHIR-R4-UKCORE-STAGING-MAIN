## Extensions

More information about the extensions can be found using the links below.

<table id="assets">
<tr>
<th width="30%">Extension</th>
<th width="30%">Context</th>
<th width="40%">Link</th>
</tr>
<tr>
<td>medicationRepeatInformation</td>
<td>MedicationRequest</td>
<td>{{pagelink: ExtensionUKCore-MedicationRepeatInformation}}</td>
</tr>
</table>

---