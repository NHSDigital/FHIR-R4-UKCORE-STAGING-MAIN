## {{page-title}}

More information on this extension can be found using the link below.

{{pagelink: ExtensionUKCore-MedicationRepeatInformation }}.

---