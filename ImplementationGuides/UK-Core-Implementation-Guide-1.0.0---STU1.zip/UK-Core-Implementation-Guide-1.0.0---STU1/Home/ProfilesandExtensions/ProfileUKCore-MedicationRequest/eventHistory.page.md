## `eventHistory`

A list of events of interest in the lifecycle and SHOULD conform to <a href="https://simplifier.net/hl7fhirukcorer4/ukcoreprovenance" target="_blank">Profile UKCore-Provenance</a>

---
