## `priorPrescription`

A reference to previous request. The resource being referenced SHOULD conform to {{pagelink:Profile-MedicationRequest-cd6802ba-6531-4cf0-b080-e1aee806f6f0}}.

Useful when the clinical system would benefit from being able to link re-supply requests with a previous request.

---
