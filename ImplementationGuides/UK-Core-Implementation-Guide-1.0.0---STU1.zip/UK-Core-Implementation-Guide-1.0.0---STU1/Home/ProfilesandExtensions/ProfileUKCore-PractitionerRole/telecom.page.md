## `telecom`

A contact detail specific to the role/location/service (e.g. a telephone number or an email address) by which the practitioner may be contacted; where `telecom` uses the {{pagelink:ContactPoint}} data type.

---



