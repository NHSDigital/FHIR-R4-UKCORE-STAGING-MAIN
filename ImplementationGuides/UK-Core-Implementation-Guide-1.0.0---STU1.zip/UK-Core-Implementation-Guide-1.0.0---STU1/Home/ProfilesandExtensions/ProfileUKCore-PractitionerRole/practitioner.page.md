## `practitioner`

The practitioner to which the role relates as a reference to {{pagelink:Profile-Practitioner-96448d2b-cd33-42cb-b1db-f48ae31db401}}.

---

