## `manufacturer`

Name of the manufacturer by reference to the organisation. The resource being referenced SHOULD conform to {{pagelink:Profile-Organization-3826477b-c49f-45cd-a6a4-a179826dd3a8}}.

---
