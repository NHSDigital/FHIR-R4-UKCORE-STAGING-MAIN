## {{page-title}}

{{pagelink:ExtensionUKCore-MedicationTradeFamily}} used to identify a Trade Family or brand associated with a Medication, specifically when the medication is defined using a dm+d Virtual Therapeutic Moiety (VTM) concept.

---
