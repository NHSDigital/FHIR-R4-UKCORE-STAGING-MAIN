## `code`

All medication SHOULD be represented using the NHS dm+d terminology.

- The `code.coding.system` SHOULD be `https://dmd.nhs.uk`.
- The `code.coding.code` SHOULD be the NHS dm+d concept code.
- The `code.coding.display` SHOULD be the NHS dm+d concept description.

---